"""Problem Set 2: Edges and Lines"""
import os
from ps2 import *

# I/O directories
input_dir = "input"
output_dir = "output"


def draw_circles(img_in, circles_array):
    """Draws circles on a given monochrome image.

    No changes are needed in this function.

    Note that OpenCV's cv2.circle( ) function requires the center point to be defined using the (x, y)
    coordinate convention.

    Args:
        img_in (numpy.array): monochrome image
        circles_array (numpy.array): numpy array of size n x 3, where n is the number of
                                     circles found by find_circles(). Each row is a (x, y, r)
                                     triple that parametrizes a circle.

    Returns:
        numpy.array: 3-channel image with circles drawn.
    """

    if len(img_in.shape) == 2:
        img_out = cv2.cvtColor(img_in, cv2.COLOR_GRAY2BGR)
    else:
        img_out = np.copy(img_in)

    for circle in circles_array:
        cv2.circle(img_out, (int(circle[1]), int(circle[0])), int(circle[2]), (0, 0, 255))
        #font = cv2.FONT_HERSHEY_SIMPLEX
        #cv2.putText(img_out, str(int(circle[2])), (int(circle[1]) - 8, int(circle[0]) + 2), font, 0.5, (0, 0, 255), 1)

    return img_out


def hough_lines_draw(img_in, peaks, rho, theta):
    """Draws lines on an image corresponding to accumulator peaks.

    This method won't be used by the autograder, but you need to implement it to
    get the images required by the problem set.

    Hint:
    Refer to http://docs.opencv.org/3.0-beta/doc/py_tutorials/py_imgproc/py_houghlines/py_houghlines.html
    to plot these lines. Notice that the first image (checkerboard) is symmetric in x and y.
    You should try with an asymmetric image to ensure you are plotting the lines properly (i.e. triangle)

    Note that OpenCV's cv2.line( ) function requires points to be defined using the (x, y) coordinate convention.

    If the input image is a 2D array you should convert it to BGR, see cv2.cvtColor( )

    Args:
        img_in (numpy.array): input image
        peaks (numpy.array): array containing the local maxima in the Hough accumulator where each row is
                             a pair of [row_id, col_id] pair
        rho (numpy.array): vector of rho values, one for each row of H.
        theta (numpy.array): vector of theta values in the range [0,pi), one for each column of H.

    Returns:
        numpy.array: 3-channel image with lines drawn.
    """
    img_in = np.copy(img_in)
    if len(img_in.shape) == 2:
        img_in = cv2.cvtColor(img_in,cv2.COLOR_GRAY2BGR)
    for peak in peaks:
        rho_value = rho[peak[0]]
        theta_value = theta[peak[1]]
        a = np.cos(theta_value)
        b = np.sin(theta_value)
        x0 = a * rho_value
        y0 = b * rho_value
        x1 = int(x0 + 1000 * (-b))
        y1 = int(y0 + 1000 * (a))
        x2 = int(x0 - 1000 * (-b))
        y2 = int(y0 - 1000 * (a))

        cv2.line(img_in, (x1, y1), (x2, y2), (0, 255, 0), 2)
        val = str(rho) + ',' + str(theta)
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(img_in, val, (x1,y1), font, 0.5, (0, 255, 0), 1)
    return img_in


def highlight_peaks(img_in, peaks):
    """Returns a version of H with the best peaks highlighted.

    This function may use cv2.circle to
    plot in color circles centered in each best peak. Alternative methods are accepted.

    If the input image is a 2D array you should convert it to BGR, see cv2.cvtColor( )

    Args:
        H (numpy.array): H accumulator array (usually normalized and scaled)
        peaks (numpy.array): array containing the local maxima in the Hough accumulator where each row is
                             a pair of [row_id, col_id] pair

    Returns:
        numpy.array: 3-channel version of H.
    """
    if len(img_in.shape) == 2:
        img_out = cv2.cvtColor(img_in, cv2.COLOR_GRAY2BGR)
    else:
        img_out = np.copy(img_in)


    for peak in peaks:
        cv2.circle(img_out, (peak[1], peak[0]), 15, (0,255,0))
    cv2.circle(img_out,(0,371),15, (0,255,0))

    return img_out


def get_edge_image(img_in, threshold1, threshold2):
    """Calls an edge function of your choice, i.e. cv2.Canny.

    You may modify this function's signature if you
    want to include more parameters. This includes removing **kwargs and adding named parameters.

    Args:
        img_in (numpy.array): input image.
        *args: additional parameters (if needed).

    Returns:
        numpy.array: edge image.
    """

    return cv2.Canny(img_in, threshold1, threshold2)


def get_smoothed_image(img_in, filterSize, sigma = 0):
    """Returns a smoothed version of img_in after using a Gaussian filter You may modify this function's signature
    if you want to include more parameters. This includes removing **kwargs and adding named parameters.

    Args:
        img_in (numpy.array): input image.
        *args: additional parameters (if needed).

    Returns:
        numpy.array: edge image.
    """

    img_in = cv2.GaussianBlur(img_in, (filterSize, filterSize), sigma)
    return img_in


def normalize_and_scale(img_in):
    """Maps values in img_in to fit in the range [0, 255]. This will be usually called before displaying or
    saving an image. You may use cv2.normalize or create your own.

    Args:
        img_in (numpy.array): input image.

    Returns:
        numpy.array: output image with pixel values in [0, 255]
    """

    res = cv2.normalize(img_in, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX)
    res = np.ndarray.astype(res, dtype=np.uint8)
    return res


def part_1(save_imgs=True):

    # 1-a
    # Load the input grayscale image
    img = cv2.imread(os.path.join(input_dir, 'ps2-input0.png'), 0)  # flags=0 ensures grayscale

    img_edges = get_edge_image(img, 200, 100)

    if save_imgs:
        cv2.imwrite(os.path.join(output_dir, 'ps2-1-a-1.png'), img_edges)

    return {"img": img, "img_edges": img_edges}


def part_2():

    # 2-a
    # Compute Hough Transform for lines on edge image
    p1 = part_1(False)
    img_edges = p1["img_edges"]
    rho_res = 1  # You may have to try different values
    theta_res = np.pi/180  # You may have to try different values
    H, rho, theta = hough_lines_acc(img_edges, rho_res, theta_res)

    # Write a normalized uint8 version of H, mapping min value from 0 to 255
    H_n = normalize_and_scale(H)
    H_n = np.ndarray.astype(H_n, np.uint8)

    cv2.imwrite(os.path.join(output_dir, 'ps2-2-a-1.png'), H_n)

    # 2-b
    # Find peaks (local maxima) in accumulator array
    hough_threshold = 100  # You may have to try different values
    nhood_delta = (2, 2)  # You may have to try different values
    peaks = hough_peaks(H, hough_threshold, nhood_delta)

    highlighted_peaks = highlight_peaks(H_n, peaks)

    cv2.imwrite(os.path.join(output_dir, 'ps2-2-b-1.png'), highlighted_peaks)

    # 2-c
    # Draw lines corresponding to accumulator peaks
    img_out = cv2.cvtColor(p1["img"], cv2.COLOR_GRAY2BGR)  # copy & convert to color image
    img_out = hough_lines_draw(img_out, peaks, rho, theta)

    cv2.imwrite(os.path.join(output_dir, 'ps2-2-c-1.png'), img_out)


def part_3():

    # 3-a
    # Read ps2-input0-noise.png, compute a smoothed image using a Gaussian filter
    img_noise = cv2.imread(os.path.join(input_dir, 'ps2-input0-noise.png'), 0)
    img_noise_smoothed = get_smoothed_image(img_noise,7)

    cv2.imwrite(os.path.join(output_dir, 'ps2-3-a-1.png'), img_noise_smoothed)

    # 3-b
    # Compute binary edge images for both original image and smoothed version
    img_noise_edges = get_edge_image(img_noise,198,146)
    img_noise_smoothed_edges = get_edge_image(img_noise_smoothed, 198, 146)

    cv2.imwrite(os.path.join(output_dir, 'ps2-3-b-1.png'), img_noise_edges)
    cv2.imwrite(os.path.join(output_dir, 'ps2-3-b-2.png'), img_noise_smoothed_edges)

    # 3-c
    # Apply Hough methods to the smoothed image, tweak parameters to find best lines
    rho_res = 1  # You may have to try different values
    theta_res = np.pi / 180  # You may have to try different values
    H, rho, theta = hough_lines_acc(img_noise_smoothed_edges, rho_res, theta_res)

    hough_threshold = 130  # You may have to try different values
    nhood_delta = (1, 1)  # You may have to try different values
    peaks = hough_peaks(H, hough_threshold, nhood_delta)

    H_n = normalize_and_scale(H).astype(np.uint8)
    highlighted_peaks = highlight_peaks(H_n, peaks)

    cv2.imwrite(os.path.join(output_dir, 'ps2-3-c-1.png'), highlighted_peaks)

    img_out_noisy = hough_lines_draw(img_noise, peaks, rho, theta)

    cv2.imwrite(os.path.join(output_dir, 'ps2-3-c-2.png'), img_out_noisy)


def part_4a():

    # 4-a
    test_circle = cv2.imread(os.path.join(input_dir, 'test_circle.png'), 0)
    # test_circle_smoothed = get_smoothed_image(test_circle)  # If needed
    test_circle = get_smoothed_image(test_circle, 5)
    test_circle_edges = get_edge_image(test_circle,100,200)  # You can use the smoothed image instead

    radius = 75
    H = hough_circles_acc(test_circle, test_circle_edges, radius, False)

    hough_threshold = 200  # You may have to try different values
    nhood_delta = (2, 2)  # You may have to try different values
    peaks = hough_peaks(H, hough_threshold, nhood_delta)

    cv2.imwrite(os.path.join(output_dir, 'ps2-4-a-1.png'), test_circle_edges)

    H_n = normalize_and_scale(H).astype(np.uint8)
    highlighted_peaks = highlight_peaks(H_n, peaks)

    cv2.imwrite(os.path.join(output_dir, 'ps2-4-a-2.png'), highlighted_peaks)


def part_4b():

    # 4-b
    test_circle = cv2.imread(os.path.join(input_dir, 'test_circle.png'), 0)
    # test_circle_smoothed = get_smoothed_image(test_circle)  # If needed
    test_circle_edges = get_edge_image(test_circle,100,200)  # You can use the smoothed image instead

    # Use hough_circles_acc with the 'point plus' method
    radius = 75
    H = hough_circles_acc(test_circle, test_circle_edges, radius)

    hough_threshold = 100  # You may have to try different values
    nhood_delta = (2, 2)  # You may have to try different values
    peaks = hough_peaks(H, hough_threshold, nhood_delta)

    # There should be only one peak given that there is one circle
    circle = np.array([[peaks[0, 0], peaks[0, 1], radius]])

    # Draw circles
    output_image = draw_circles(test_circle, circle)

    cv2.imwrite(os.path.join(output_dir, 'ps2-4-b-1.png'), output_image)


def part_5a():

    # From this point on you will only use the 'point plus' method
    # 5-a
    pens_and_coins = cv2.imread(os.path.join(input_dir, 'ps2-input1.png'), 0)
    pens_and_coins_smoothed = get_smoothed_image(pens_and_coins,5)  # If needed
    pens_and_coins_edges = get_edge_image(pens_and_coins_smoothed, 200, 350)  # You can use the smoothed image instead

    rho_res = 1  # You may have to try different values
    theta_res = np.pi / 180  # You may have to try different values
    H, rho, theta = hough_lines_acc(pens_and_coins_edges, rho_res, theta_res)

    hough_threshold = 100  # You may have to try different values
    nhood_delta = (4, 4)  # You may have to try different values
    peaks = hough_peaks(H, hough_threshold, nhood_delta)

    H_n = normalize_and_scale(H).astype(np.uint8)
    highlighted_peaks = highlight_peaks(H_n, peaks)
    cv2.imwrite(os.path.join(output_dir, 'ps2-5-a-1.png'), highlighted_peaks)

    img_out = hough_lines_draw(pens_and_coins, peaks, rho, theta)

    cv2.imwrite(os.path.join(output_dir, 'ps2-5-a-2.png'), img_out)


def part_5b():

    smooth_filter = 5
    threshold1 = 200
    threshold2 = 250
    hough_threshold = 155
    nhood_delta = (10,10)
    sigma = 0
    for smooth_filter in np.arange(1,11,step=2):
        for threshold1 in np.arange(250,1,step=-20):
            for threshold2 in np.arange(250,threshold1, step=-20):
                for hough_threshold in np.arange(250,100,step=-5):
                    for sigma in np.arange(0,5,step=1):

                        name = str(smooth_filter) + '-' + str(threshold1) + '-' + str(threshold2) + \
                               '-' + str(hough_threshold)  + '-' + str(sigma)
                        # 5-b
                        pens_and_coins = cv2.imread(os.path.join(input_dir, 'ps2-input1.png'), 0)
                        pens_and_coins_smoothed = get_smoothed_image(pens_and_coins,smooth_filter)
                        pens_and_coins_edges = get_edge_image(pens_and_coins_smoothed, threshold1, threshold2)

                        radius = 23  # Fixed radius DO NOT change it. It will be used for grading.
                        H = hough_circles_acc(pens_and_coins, pens_and_coins_edges, radius)
                        peaks = hough_peaks(H, hough_threshold, nhood_delta)

                        # There could be more than one peak returned. Now draw all the non-overlapping circles
                        circles = np.column_stack((peaks[:, 0], peaks[:, 1], [radius] * len(peaks)))

                        # Draw circles
                        output_image = draw_circles(pens_and_coins, circles)

                        cv2.imwrite(os.path.join(output_dir, 'ps2-5-b-1-' + name + '.png'), output_image)
                        cv2.imwrite(os.path.join(output_dir, 'ps2-5-b-1-deges-' + name + '.png'), pens_and_coins_edges)


def part_5c():
    # 5-c
    pens_and_coins = cv2.imread(os.path.join(input_dir, 'ps2-input1.png'), 0)
    pens_and_coins_smoothed = get_smoothed_image(pens_and_coins,5)  # If needed
    pens_and_coins_edges = get_edge_image(pens_and_coins_smoothed, 100, 200)  # You can use the smoothed image instead

    radii = range(16, 30, 1)  # Try different values
    hough_threshold = 100  # You may have to try different values
    nhood_delta = (5, 5)  # You may have to try different values
    circles = find_circles(pens_and_coins, pens_and_coins_edges, radii, hough_threshold, nhood_delta,
                           theta_range=3, collision_detection_range=(6,6))
    circles = circles[0:14,:]
    print circles
    output_image = draw_circles(pens_and_coins, circles)
    cv2.imwrite(os.path.join(output_dir, 'ps2-5-c-1.png'), output_image)


def part_6():
    """Finds and plots lines and circles in the image ps2-input2.png. This part should accurately detect
    the pens and coins. For more information follow the problem set documentation.

    The images to be saved are:
    - ps2-6-a-1.png
    - ps2-6-b-1.png
    - ps2-6-c-1.png

    Returns:
        None.
    """
    cluttered_image = cv2.imread(os.path.join(input_dir, 'ps2-input2.png'), 0)
    #part_6a(cluttered_image)
    part_6b(cluttered_image)
    #part_6c(cluttered_image)

    # 3-c
    # Apply Hough methods to the smoothed image, tweak parameters to find best lines

#1. Find at least the pen lines
def part_6a(cluttered_image):
    smooth_filter = 5
    threshold1 = 100
    threshold2 = 200
    hough_threshold = 183
    nhood_delta = (10,10)
    rho_res = 1  # You may have to try different values
    theta_res = np.pi / 180  # You may have to try different values

    cluttered_image_smoothed = get_smoothed_image(cluttered_image, 5)
    cluttered_image_edges = get_edge_image(cluttered_image_smoothed, threshold1, threshold2)
    cv2.imwrite('output/ps2-6-a-1-edges.png', cluttered_image_edges)

    H, rho, theta = hough_lines_acc(cluttered_image_edges, rho_res, theta_res, return_line_points_dict=False)
    peaks = hough_peaks(H, hough_threshold, nhood_delta)
    print 'Lines found: ',  peaks.shape[0]

    H_n = normalize_and_scale(H).astype(np.uint8)
    cluttered_image_smoothed_with_lines = hough_lines_draw(cluttered_image, peaks, rho, theta)
    cv2.imwrite(os.path.join(output_dir, 'ps2-6-a-1.png'), cluttered_image_smoothed_with_lines)
    cv2.imwrite('output/ps2-6-a-1-H.png', H_n)

#find only the 4 pens edges: thresholding, minimum length, search for parallel lines
def part_6b(cluttered_image):
    smooth_filter = 5
    threshold1 = 100
    threshold2 = 200
    hough_threshold = 183
    nhood_delta = (10,10)
    rho_res = 1  # You may have to try different values
    theta_res = np.pi / 180  # You may have to try different values

    cluttered_image_smoothed = get_smoothed_image(cluttered_image, 5)
    cluttered_image_edges = get_edge_image(cluttered_image_smoothed, threshold1, threshold2)
    cv2.imwrite('output/ps2-6-b-1-edges.png', cluttered_image_edges)

    H, rhos, thetas, d = hough_lines_acc(cluttered_image_edges, rho_res, theta_res, return_line_points_dict=True)
    peaks = hough_peaks(H, hough_threshold, nhood_delta)
    print 'Lines found: ',  peaks.shape[0]
    for peak in peaks:
        print 'rhos:', rhos[peak[0]], ';  thetas in degrees:', thetas[peak[1]]*180 / np.pi, \
            '; Line length:', get_line_length(peak,d), \
            '; Point density:', get_point_density(peak, d)

    points = plot_points_for_lines(peaks, d, cluttered_image.shape)
    cv2.imwrite('output/ps2-6-b-1-points.png', points)

    #sort by angle and choose same angle/small distance pairs of lines
    peaks = np.array(sorted(peaks, key = lambda row: row[1]))
    res = []
    for i in range(0, peaks.shape[0] -1):
        if abs(peaks[i,1] - peaks[i+1,1]) <= 1 and np.abs(peaks[i,0] - peaks[i+1,0]) < 40:
            res.append(peaks[i])
            res.append(peaks[i+1])
    peaks = np.array(res)

    H_n = normalize_and_scale(H).astype(np.uint8)
    cluttered_image_smoothed_with_lines = hough_lines_draw(cluttered_image, peaks, rhos, thetas)
    cv2.imwrite(os.path.join(output_dir, 'ps2-6-b-1.png'), cluttered_image_smoothed_with_lines)
    cv2.imwrite('output/ps2-6-b-1-H.png', H_n)

#compute the lenght of the line given by the given (rho,theta) as the distance
#between the farthest 2 points
def get_line_length(peak, d):
    points = d[(peak[0],peak[1])]
    points = np.array(points)
    x_min = np.amin(points[:,0])
    x_max = np.amax(points[:, 0])
    y_min = np.amin(points[:,1])
    y_max = np.amax(points[:, 1])
    return np.sqrt((x_max - x_min)**2 + (y_max - y_min)**2)

def get_point_density(peak, d):
    return get_line_length(peak,d) * 1.0 / len(d[(peak[0],peak[1])])

#plot all edge points which voted for the line given by given peak
def plot_points_for_lines(peaks, d, shape):
    res = np.zeros(shape)
    for peak in peaks:
        points = np.array(d[peak[0],peak[1]])
        for point in points:
            res[point[0],point[1]] = 255
    return res


#find all the circles
def part_6c(cluttered_image):
    smooth_filter = 3
    threshold1 = 50
    threshold2 = 120
    radii = range(25, 35, 1)
    hough_threshold = 100
    nhood_delta = (5, 5)
    theta_range = 5
    collision_detection_range = (25, 25)

    smoothed = get_smoothed_image(cluttered_image,smooth_filter)
    edges = get_edge_image(smoothed, threshold1, threshold2)
    circles = find_circles(cluttered_image, edges, radii, hough_threshold, nhood_delta, theta_range=theta_range,
                           collision_detection_range=collision_detection_range)
    circles = circles[0:15,:]
    print circles
    output_image = draw_circles(cluttered_image, circles)
    cv2.imwrite(os.path.join(output_dir, 'ps2-6-c-1.png'), output_image)
    cv2.imwrite('output/ps2-6-c-edges.png', edges)

def part_8(cluttered_image):
    smooth_filter = 5
    threshold1 = 100
    threshold2 = 200
    hough_threshold = 250
    nhood_delta = (5,5)
    rho_res = 1  # You may have to try different values
    theta_res = np.pi / 180  # You may have to try different values

    cluttered_image_smoothed = get_smoothed_image(cluttered_image, 5)
    cluttered_image_edges = get_edge_image(cluttered_image_smoothed, threshold1, threshold2)
    cv2.imwrite('output/ps2-6-a-edges.png', cluttered_image_edges)

    H, rho, theta, d = hough_lines_acc(cluttered_image_edges, rho_res, theta_res, return_line_points_dict=False)
    peaks = hough_peaks(H, hough_threshold, nhood_delta)

    #TODO - remove here
    example_peak = peaks[0]
    x=example_peak[0]
    y=example_peak[1]
    points = d[(x,y)]
    test = np.zeros(cluttered_image.shape)
    for point in points:
        test[point[0],point[1]] = 255
        cv2.imwrite('output/ps2-6-a-first-line.png', test)


    H_n = normalize_and_scale(H).astype(np.uint8)
    cluttered_image_smoothed_with_lines = hough_lines_draw(cluttered_image, peaks, rho, theta)
    cv2.imwrite(os.path.join(output_dir, 'ps2-6-a-1.png'), cluttered_image_smoothed_with_lines)
    cv2.imwrite('output/ps2-6-a-H.png', H_n)


if __name__ == '__main__':
    # part_1()
    # part_2()
    # part_3()
    # part_4a()
    # part_4b()
    #part_5a()
    #part_5b()
    #part_5c()
    part_6()
    # TODO: Don't forget to answer part 7 in your report
    #part_8()
