import experiment
import numpy as np
import cv2
import ps2

def runCircle():
    radius = 20
    image = createCircleImage(radius)
    edges = experiment.get_edge_image(image, 200, 100)
    cv2.imwrite('output/circle.png', image)
    cv2.imwrite('output/circle_edges.png', image)
    sobel_x, sobel_y = ps2.compute_gradients(edges)
    H = ps2.hough_circles_acc(image,image,radius)
    cv2.imshow('H', experiment.normalize_and_scale(H))
    np.savetxt('output/sobel-x.csv', sobel_x, delimiter=',')
    np.savetxt('output/sobel-y.csv', sobel_y, delimiter=',')
    np.savetxt('output/H.csv', H, delimiter=',')


def createVerticalLineImage():
    size = 9
    image = np.zeros((size, size))
    for i in np.arange(0,size):
        image[i,size/2] = 255
    return np.ndarray.astype(image, np.uint8)

def createDiagonalLineImage():
    size = 9
    image = np.zeros((size, size))
    for i in np.arange(0,size):
        image[i,i] = 255
    return np.ndarray.astype(image, np.uint8)

def createCircleImage(radius):
    size = radius * 2 + 20
    x0 = size/2
    y0 = size/2
    image = np.zeros((size, size))
    for theta in np.arange(0,np.pi * 2,np.pi/360):
        x = int(x0 + radius*np.sin(theta))
        y = int(y0 + radius*np.cos(theta))
        image[x,y] = 255
    return np.ndarray.astype(image, np.uint8)


if __name__ == '__main__':
    runCircle()
    cv2.waitKey(0)