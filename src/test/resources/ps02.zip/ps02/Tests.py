import numpy as np
import cv2
import ps2
import experiment


def draw_lines():
    pens_and_coins = cv2.imread('input/ps2-input1.png')
    pens_and_coins_smoothed = experiment.get_smoothed_image(pens_and_coins, 5)
    pens_and_coins_edges = experiment.get_edge_image(pens_and_coins_smoothed, 200, 350)  # You can use the smoothed image instead
    cv2.imwrite('output/pens_and_coins_edges.png', pens_and_coins_edges)

    rho_res = 1  # You may have to try different values
    theta_res = np.pi / 180  # You may have to try different values
    H, rho, theta = ps2.hough_lines_acc(pens_and_coins_edges, rho_res, theta_res)
    cv2.imwrite('output/pens_and_coins_hough_lines.png', H)
    peaks = ps2.hough_peaks(H,100,(4,4))
    print peaks
    experiment.hough_lines_draw(pens_and_coins,peaks,rho,theta)
    cv2.imwrite('output/pens_and_coins_with_drown_edges.png', pens_and_coins)

def draw_circles():
    pens_and_coins = cv2.imread('input/ps2-input1.png')
    pens_and_coins_smoothed = experiment.get_smoothed_image(pens_and_coins, 5)
    pens_and_coins_edges = experiment.get_edge_image(pens_and_coins_smoothed, 200, 255)  # You can use the smoothed image instead
    cv2.imwrite('output/pens_and_coins_edges.png', pens_and_coins_edges)

    radius = 23  # Fixed radius DO NOT change it. It will be used for grading.
    H = ps2.hough_circles_acc(pens_and_coins, pens_and_coins_edges, radius)
    cv2.imshow('output/H.png', experiment.normalize_and_scale(H))
    get_peaks_and_draw_circles(pens_and_coins, H, radius, 150, (5,5))
    cv2.waitKey(0)

def get_peaks_and_draw_circles(original_image, H, radius, hough_threshold, nhood_delta):
    peaks = ps2.hough_peaks(H, hough_threshold, nhood_delta)

    # There could be more than one peak returned. Now draw all the non-overlapping circles
    circles = np.column_stack((peaks[:, 0], peaks[:, 1], [radius] * len(peaks)))
    # Draw circles

    output_image = experiment.draw_circles(original_image, circles)
    cv2.imwrite('output/pens_and_coins_hough_circles_' + str(hough_threshold) + '_' + str(nhood_delta) + '.png', output_image)

if __name__ == '__main__':
    draw_circles()