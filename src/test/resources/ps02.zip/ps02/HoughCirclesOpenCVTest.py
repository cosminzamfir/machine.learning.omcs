import cv2
import numpy as np
import experiment

pens_and_coins = cv2.imread('input/ps2-input1.png')
output = np.copy(pens_and_coins)
pens_and_coins = cv2.cvtColor(pens_and_coins, cv2.COLOR_BGR2GRAY)
pens_and_coins_smoothed = experiment.get_smoothed_image(pens_and_coins, 5)
pens_and_coins_edges = experiment.get_edge_image(pens_and_coins_smoothed, 200,
                                                 350)  # You can use the smoothed image instead
circles = cv2.HoughCircles(pens_and_coins_smoothed,cv2.cv.CV_HOUGH_GRADIENT, 1.2, 1, maxRadius=40, param2=70)

# ensure at least some circles were found
if circles is not None:
    # convert the (x, y) coordinates and radius of the circles to integers
    circles = np.round(circles[0, :]).astype("int")

    # loop over the (x, y) coordinates and radius of the circles
    for (x, y, r) in circles:
        # draw the circle in the output image, then draw a rectangle
        # corresponding to the center of the circle
        cv2.circle(output, (x, y), r, (0, 255, 0), 1)
        #cv2.rectangle(output, (x - 5, y - 5), (x + 5, y + 5), (0, 128, 255), -1)

    # show the output image
    cv2.imshow("output", output)
    cv2.waitKey(0)
