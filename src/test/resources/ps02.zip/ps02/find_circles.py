import argparse
import cv2
import os
from circles_finder import CirclesFinder


def main():
    parser = argparse.ArgumentParser(description='Visualizes the circle hough transform.')
    parser.add_argument('filename')

    args = parser.parse_args()

    img = cv2.imread(args.filename, cv2.IMREAD_GRAYSCALE)

    #cv2.imshow('input', img)

    circle_finder = CirclesFinder(img, filter_size=5, threshold1=100, threshold2=200, hough_threshold=200, nhood_delta=5)

    print "Edge parameters:"
    print "GaussianBlur Filter Size: %f" % circle_finder.filterSize()
    print "Threshold1: %f" % circle_finder.threshold1()
    print "Threshold2: %f" % circle_finder.threshold2()
    print "Hough threshold: %f" % circle_finder.houghThreshold()
    print "Nhood delta: %f" % circle_finder.nhoodDelta()


    (head, tail) = os.path.split(args.filename)

    (root, ext) = os.path.splitext(tail)

    smoothed_filename = os.path.join("output_images", root + "-smoothed" + ext)
    edge_filename = os.path.join("output_images", root + "-edges" + ext)

    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()
