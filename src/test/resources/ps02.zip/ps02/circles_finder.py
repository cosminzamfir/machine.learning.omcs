import cv2
import numpy as np
import ps2
import experiment


class CirclesFinder:
    def __init__(self, image, filter_size=1, threshold1=0, threshold2=0, hough_threshold=0, nhood_delta = 0):
        self.image = image
        self._filter_size = filter_size
        self._threshold1 = threshold1
        self._threshold2 = threshold2
        self._hough_threshold = hough_threshold
        self._nhood_delta = nhood_delta

        def onchangeThreshold1(pos):
            self._threshold1 = pos
            self._render()

        def onchangeThreshold2(pos):
            self._threshold2 = pos
            self._render()

        def onchangeFilterSize(pos):
            self._filter_size = pos
            self._filter_size += (self._filter_size + 1) % 2
            self._render()

        def onChangeHoughThreshold(pos):
            self._hough_threshold = pos
            self._render()

        def onChangeNhoodDelta(pos):
            self._nhood_delta = pos
            self._render()

        cv2.namedWindow('circles')

        cv2.createTrackbar('threshold1', 'circles', self._threshold1, 255, onchangeThreshold1)
        cv2.createTrackbar('threshold2', 'circles', self._threshold2, 255, onchangeThreshold2)
        cv2.createTrackbar('filter_size', 'circles', self._filter_size, 20, onchangeFilterSize)
        cv2.createTrackbar('hough_threshold', 'circles', self._hough_threshold, 255, onChangeHoughThreshold)
        cv2.createTrackbar('nhood_delta', 'circles', self._nhood_delta, 20, onChangeNhoodDelta)

        self._render()

        print "Adjust the parameters as desired.  Hit any key to close."

        cv2.waitKey(0)

        cv2.destroyWindow('edges')
        cv2.destroyWindow('smoothed')

    def threshold1(self):
        return self._threshold1

    def threshold2(self):
        return self._threshold2

    def filterSize(self):
        return self._filter_size

    def houghThreshold(self):
        return self._hough_threshold

    def nhoodDelta(self):
        return self._nhood_delta

    def edgeImage(self):
        return self._edge_img

    def smoothedImage(self):
        return self._smoothed_img

    def _render(self):
        self._smoothed_img = cv2.GaussianBlur(self.image, (self._filter_size, self._filter_size), sigmaX=0, sigmaY=0)
        self._edge_img = cv2.Canny(self._smoothed_img, self._threshold1, self._threshold2)
        cv2.imshow('smoothed', self._smoothed_img)
        cv2.imshow('edges', self._edge_img)

        radius = 23  # Fixed radius DO NOT change it. It will be used for grading.
        H = ps2.hough_circles_acc(self.image, self._edge_img, radius)
        cv2.imshow('H', experiment.normalize_and_scale(H))

        peaks = ps2.hough_peaks(H, self._hough_threshold, (self._nhood_delta,self._nhood_delta))
        print 'Number of peaks', peaks.shape[0]
        print '================================================================================='
        # There could be more than one peak returned. Now draw all the non-overlapping circles
        circles = np.column_stack((peaks[:, 0], peaks[:, 1], [radius] * len(peaks)))
        # Draw circles
        output_image = experiment.draw_circles(self.image, circles)
        cv2.imshow('circles', output_image)
