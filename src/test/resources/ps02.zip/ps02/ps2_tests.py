import unittest
import cv2
import ps2
import numpy as np
import experiment

class MyTestCase(unittest.TestCase):

    def test_get_edge_points(self):
        image = cv2.imread('input/ps2-input0.png')
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(image, 100, 200)
        edge_points = ps2.get_edge_points(edges)
        self.assertTrue(edge_points.shape[0] < np.ndarray.flatten(image).shape[0])
        self.assertEqual(edge_points.shape[1],2)

    def test_initialize_grid(self):
        image = np.array([[1,2,3],[1,2,3],[1,2,3],[1,2,3]])
        H, rhos, thetas = ps2.initialize_grid(image, 1, np.pi/180)
        self.assertEqual(H.shape[0],10)
        self.assertEqual(H.shape[1], 180)
        self.assertEqual(rhos.shape[0], 10)
        self.assertEqual(thetas.shape[0], 180)

    def test_get_indices(self):
        image = np.array([[1,2,3],[1,2,3],[1,2,3],[1,2,3]])
        H, rhos, thetas = ps2.initialize_grid(image, 1, np.pi/180)
        indices = ps2.get_indices(5, np.pi, 1, np.pi / 180, rhos, thetas)
        self.assertEqual(indices[0],9)
        self.assertEqual(indices[1],179)

        indices = ps2.get_indices(0, 0, 1, np.pi / 180, rhos, thetas)
        self.assertEqual(indices[0],5)
        self.assertEqual(indices[1],0)

    def test_vote(self):
        image = np.array([[1,2,3],[1,2,3],[1,2,3],[1,2,3]])
        H, rhos, thetas = ps2.initialize_grid(image, 1, np.pi/180)
        ps2.vote(H, 0, 0, 1, np.pi/180, rhos, thetas)
        self.assertEqual(H[5][0], 1)
        self.assertEqual(H[5][1], 0)
        self.assertEqual(H[6][0], 0)

    def test_hough_line_acc(self):
        image = cv2.imread('input/ps2-input0.png')
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(image, 100, 200)
        H, rhos, thetas = ps2.hough_lines_acc(edges, 1, np.pi/180)
        H = cv2.normalize(H, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX)
        cv2.imwrite('output/hough.res.png', H)
        self.assertEqual(np.max(H),255)

    def test_hough_peaks(self):
        image = cv2.imread('input/ps2-input0.png')
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(image, 100, 200)
        H, rhos, thetas = ps2.hough_lines_acc(edges, 1, np.pi/180)
        H = cv2.normalize(H, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX)
        peaks = ps2.hough_peaks(H,100,(2,2))
        self.assertEqual(peaks.shape[0],6)

    def test_hough_lines_draw(self):
        image = cv2.imread('input/ps2-input0.png')
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(image, 100, 200)
        H, rhos, thetas = ps2.hough_lines_acc(edges, 1, np.pi/180)
        H = cv2.normalize(H, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX)
        peaks = ps2.hough_peaks(H,100,(2,2))
        image = experiment.hough_lines_draw(image,peaks,rhos, thetas)
        cv2.imwrite('output/hough_lines.png', image)

    def test_hough_circles_acc_single_point(self):
        image = cv2.imread('input/test_circle.png')
        edges = cv2.Canny(image,100,200)
        H = ps2.hough_circles_acc(image, edges, 75, False)
        H = cv2.normalize(H, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX)
        cv2.imwrite('output/h_circle_single_point.png', H)
        cv2.imwrite('output/circle_edges.png', edges)
        peaks = ps2.hough_peaks(H,200,(2,2))
        self.assertEqual(peaks.shape[0],1)
        self.assertEqual(peaks[0,0], 199)
        self.assertEqual(peaks[0,1], 199)

    def test_compute_gradients_thetas(self):
        image = cv2.imread('input/test_circle.png')
        img_edges = cv2.Canny(image,100,200)
        edge_points = ps2.get_edge_points(img_edges)
        thetas = ps2.compute_gradients_thetas(img_edges, edge_points, 5)

    def test_hough_circles_acc_point_plus_gradient(self):
        image = cv2.imread('input/test_circle.png')
        edges = cv2.Canny(image,100,200)
        H = ps2.hough_circles_acc(image, edges, 75, True)
        H = cv2.normalize(H, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX)
        cv2.imwrite('output/h_circle_point_plus_gradient.png', H)
        cv2.imwrite('output/circle_edges.png', edges)
        peaks = ps2.hough_peaks(H,200,(2,2))
        self.assertEqual(peaks.shape[0],1)
        self.assertEqual(peaks[0,0], 200)
        self.assertEqual(peaks[0,1], 200)

if __name__ == '__main__':
    unittest.main()
