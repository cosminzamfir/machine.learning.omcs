import cv2
import experiment
import ps2
import numpy as np


class EdgeFinder:
    def __init__(self, image, filter_size=1, threshold1=0, threshold2=0, hough_threshold=200, nhood_delta = 5):
        self.image = image
        self._filter_size = filter_size
        self._threshold1 = threshold1
        self._threshold2 = threshold2
        self._hough_threshold = hough_threshold
        self._nhood_delta = nhood_delta

        def onchangeNhoodDelta(pos):
            self._nhood_delta = pos
            self._render()

        def onchangeHoughThreshold(pos):
            self._hough_threshold = pos
            self._render()

        def onchangeThreshold1(pos):
            self._threshold1 = pos
            self._render()

        def onchangeThreshold2(pos):
            self._threshold2 = pos
            self._render()

        def onchangeFilterSize(pos):
            self._filter_size = pos
            self._filter_size += (self._filter_size + 1) % 2
            self._render()

        cv2.namedWindow('edges')

        cv2.createTrackbar('threshold1', 'edges', self._threshold1, 255, onchangeThreshold1)
        cv2.createTrackbar('threshold2', 'edges', self._threshold2, 255, onchangeThreshold2)
        cv2.createTrackbar('filter_size', 'edges', self._filter_size, 20, onchangeFilterSize)
        cv2.createTrackbar('hough_threshold', 'edges', self._filter_size, 255, onchangeHoughThreshold)
        cv2.createTrackbar('nhood_delta', 'edges', self._filter_size, 255, onchangeNhoodDelta)

        self._render()

        print "Adjust the parameters as desired.  Hit any key to close."

        cv2.waitKey(0)

        cv2.destroyWindow('edges')
        cv2.destroyWindow('smoothed')

    def threshold1(self):
        return self._threshold1

    def threshold2(self):
        return self._threshold2

    def filterSize(self):
        return self._filter_size

    def edgeImage(self):
        return self._edge_img

    def smoothedImage(self):
        return self._smoothed_img

    def _render(self):
        self._smoothed_img = cv2.GaussianBlur(self.image, (self._filter_size, self._filter_size), sigmaX=0, sigmaY=0)
        self._edge_img = cv2.Canny(self._smoothed_img, self._threshold1, self._threshold2)
        H, rhos, thetas = ps2.hough_lines_acc(self._edge_img, 1, np.pi/180)
        peaks = ps2.hough_peaks(H, self._hough_threshold, (self._nhood_delta,self._nhood_delta))
        image_with_lines = experiment.hough_lines_draw(self.image, peaks, rhos, thetas)
        cv2.imshow('smoothed', self._smoothed_img)
        cv2.imshow('edges', self._edge_img)
        cv2.imshow('lines', image_with_lines)
