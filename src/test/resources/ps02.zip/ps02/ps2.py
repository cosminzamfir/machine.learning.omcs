"""Problem Set 2: Edges and Lines."""

import math
import numpy as np
import cv2


def hough_lines_acc(img_edges, rho_res, theta_res, return_line_points_dict=False):
    """ Creates and returns a Hough accumulator array by computing the Hough Transform for lines on an
    edge image.

    This method defines the dimensions of the output Hough array using the rho and theta resolution
    parameters. The Hough accumulator is a 2-D array where its rows and columns represent the index
    values of the vectors rho and theta respectively. The length of each dimension is set by the
    resolution parameters. For example: if rho is a vector of values that are in [0, a_1, a_2, ... a_n],
    and rho_res = 1, rho should remain as [0, a_1, a_2, ... , a_n]. If rho_res = 2, then rho would
    be half its length i.e [0, a_2, a_4, ... , a_n] (assuming n is even). The same description applies
    to theta_res and the output vector theta. These two parameters define the size of each bin in
    the Hough array.

    Note that indexing using negative numbers will result in calling index values starting from
    the end. For example, if b = [0, 1, 2, 3, 4] calling b[-2] will return 3.

    Args:
        img_edges (numpy.array): edge image (every nonzero value is considered an edge).
        rho_res (int): rho resolution (in pixels).
        theta_res (float): theta resolution (in degrees converted to radians i.e 1 deg = pi/180).

    Returns:
        tuple: Three-element tuple containing:
               H (numpy.array): Hough accumulator array.
               rho (numpy.array): vector of rho values, one for each row of H
               theta (numpy.array): vector of theta values, one for each column of H.
    """

    # 1. create a grid:
        # row=theta value (0 : 180 : step theta_res)
        # column=ro value (0 : image diagonal size : step rho_res)
        # the 'grid' consists of 3 arrays:
        # H - the 2 dimensional array containing the votes count
        # rhos - one-dimensional array with the rho values
        # thetas - one-dimensioan array with the theta values
    # 2. get all edge points
    # 3. for each edge point (x,y), any line that crosses that point has a (ro,theta) satisfying the relation:
        # ro=y*cos(theta)+x*sin(theta) - note that swap of x with y, as the x in the pixel position refers to vertical axis
    # 4. iterate theta in the grid, compute rho, get the corresponding column for ro and theta, increment the grid value
    line_points_dict = dict()
    H, rhos, thetas = initialize_grid(img_edges, rho_res, theta_res)
    edge_points = get_edge_points(img_edges)
    print 'Edge points:', edge_points.shape[0]
    for edge_point in edge_points:
        x = edge_point[0]
        y = edge_point[1]
        for theta in thetas:
            rho = y * np.cos(theta) + x * np.sin(theta)
            H = vote(H, rho, theta, rho_res, theta_res, rhos, thetas, line_points_dict,x,y)
    if return_line_points_dict:
        return H, rhos, thetas, line_points_dict
    else:
        return H, rhos, thetas

# rho : from -(x^2+y^2) to +(x^2+y^2)
# theta: from 0 to PI
def initialize_grid(image, rho_res, theta_res):
    diag_size = np.ceil(np.sqrt(image.shape[0] ** 2 + image.shape[1] ** 2))
    rho = np.arange(-diag_size, diag_size, rho_res)
    theta = np.arange(0, np.pi, theta_res)
    H = np.zeros((len(rho), len(theta)))
    return H, rho, theta


# return a 2D arrays, each row being the x,y coordinates of an edge point
def get_edge_points(img_edges):
    return np.transpose(np.nonzero(img_edges))


#increment the value of the accumulator array corresponding
#to the given rho and theta
def vote(H, rho, theta, rho_res, theta_res, rhos, thetas, line_points_dict,x,y):
    rho_index, theta_index = get_indices(rho, theta, rho_res, theta_res, rhos, thetas)
    H[rho_index][theta_index] += 1
    if (rho_index,theta_index) in line_points_dict:
        line_points_dict[(rho_index,theta_index)].append((x,y))
    else:
        list = []
        list.append((x,y))
        line_points_dict[(rho_index,theta_index)] = list
    return H


#compute the indices of the given rho and theta,
#given the rho_res and theta_res and the rho and theta arrays
def get_indices(rho, theta, rho_res, theta_res, rhos, thetas):
    rho_index = int(min(np.floor((rho - rhos[0]) / rho_res), len(rhos) - 1))
    theta_index = int(min(np.floor(theta / theta_res), len(thetas) - 1))
    return rho_index, theta_index


def hough_peaks(H, hough_threshold, nhood_delta, rows=None, cols=None):
    """Returns the best peaks in a Hough Accumulator array.

    This function selects the pixels with the highest intensity values in an area and returns an array
    with the row and column indices that correspond to a local maxima. This search will only look at pixel
    values that are greater than or equal to hough_threshold.

    Part of this function performs a non-maxima suppression using the parameter nhood_delta which will
    indicate the area that a local maxima covers. This means that any other pixels, with a non-zero values,
    that are inside this area will not be counted as a peak eliminating possible duplicates. The
    neighborhood is a rectangular area of shape nhood_delta[0] * 2 by nhood_delta[1] * 2.

    When working with hough lines, you may need to use the true value of the rows and columns to suppress
    duplicate values due to aliasing. You can use the rows and cols parameters to access the true value of
    for rho and theta at a specific peak.

    Args:
        H (numpy.array): Hough accumulator array.
        hough_threshold (int): minimum pixel intensity value in the accumulator array to search for peaks
        nhood_delta (tuple): a pair of integers indicating the distance in the row and
                             column indices deltas over which non-maximal suppression should take place.
        rows (numpy.array): array with values that map H rows. Default set to None.
        cols (numpy.array): array with values that map H columns. Default set to None.

    Returns:
        numpy.array: Output array of shape Q x 2 where each row is a [row_id, col_id] pair
                     where the peaks are in the H array and Q is the number of the peaks found in H.
    """
    # In order to standardize the range of hough_threshold values let's work with a normalized version of H.
    H_norm = cv2.normalize(H.copy(), alpha=0, beta=255, norm_type=cv2.NORM_MINMAX)
    m = H_norm.shape[1]
    n = H_norm.shape[0]
    res = []
    for i in range(0,n):
        for j in range(0,m):
            if H_norm[i,j] < hough_threshold:
                continue
            i_start = max(0,i-nhood_delta[0])
            i_end = min(n, i+nhood_delta[0])
            j_start = max(0,j-nhood_delta[1])
            j_end = min(m,j+nhood_delta[1])
            if np.max(H_norm[i_start:i_end, j_start:j_end]) <= H_norm[i,j]:
                res.append([i,j])
                H_norm[i_start:i_end, j_start:j_end] = 0

    # Once you have all the detected peaks, you can eliminate the ones that represent
    # the same line. This will only be helpful when working with Hough lines.
    # The autograder does not pass these parameters when using a Hough circles array because it is not
    # needed. You can opt out from implementing this part, make sure you comment it out or delete it.
    if rows is not None and cols is not None:
        # Aliasing Suppression.
        pass

    return np.array(res)


def hough_circles_acc(img_orig, img_edges, radius, point_plus=True, theta_range = 0):
    """Returns a Hough accumulator array using the Hough Transform for circles.

    This function implements two methods: 'single point' and 'point plus'. Refer to the problem set
    instructions and the course lectures for more information about them.

    For simplicity purposes, this function returns an array of the same dimensions as img_edges.
    This means each bin corresponds to one pixel (there are no changes to the grid discretization).

    Note that the 'point plus' method requires gradient images in X and Y (see cv2.Sobel) using
    img_orig to perform the voting.

    Args:
        img_orig (numpy.array): original image.
        img_edges (numpy.array): edge image (every nonzero value is considered an edge).
        radius (int): radius value to look for.
        point_plus (bool): flag that allows to choose between 'single point' or 'point plus'.

    Returns:
        numpy.array: Hough accumulator array.
    """

    if point_plus == False:
        return single_point(img_orig, img_edges, radius)
    else:
        return point_plus_gradient(img_orig, img_edges, radius, theta_range)

#1. initialize the accumulator array: 2D array with the same size as the img_edge
#2. iterate the edgepoints and for each edge-point:
    #compute the centers of all circles which can have the edge-point on the perimeter
    #increment the accumulator array
def single_point(img_orig, img_edges, radius):
    height = img_edges.shape[0]
    width = img_edges.shape[1]
    H = np.zeros((height, width))
    edge_points = get_edge_points(img_edges)
    for edge_point in edge_points:
        x0 = edge_point[0]
        y0 = edge_point[1]
        for theta in np.arange(0, 2 * np.pi, np.pi / 360):
            x = int(x0 + radius * np.sin(theta))
            y = int(y0 + radius * np.cos(theta))
            # print x,y
            if x < height and y < width:
                H[x, y] += 1
    return H


#for every edge point compute the gradient angle (theta)
#as the gradient is perpendicular to the tangent of the line => the radius of the circle is on the same line as the gradient vector
#in other words, in hough space, what correspond to an edge point is a line starting from that point and with an angle equal
#to the one made by the gradient line
def point_plus_gradient(img_orig, img_edges, radius, theta_range):
    height = img_edges.shape[0]
    width = img_edges.shape[1]
    H = np.zeros((height, width))
    edge_points = get_edge_points(img_edges)
    print 'Running point_plus_gradient for radius:' + str(radius)
    print 'Edge points:', edge_points.shape[0]
    gradients_thetas = compute_gradients_thetas(img_edges, edge_points, 5)
    bad_gradients = 0
    for edge_point,theta in zip(edge_points, gradients_thetas):
        if np.inf == theta:
            bad_gradients += 1
        else:
            H = vote_for_point_plus_gradient_line(H, edge_point, theta, radius, theta_range)
    print 'Edge-points with zero dy and dx gradients:', str(bad_gradients)
    #print
    # a = np.copy(H, H.shape[0]*H.shape[1])
    # a.sort()
    # a = a[::-1]
    # a = a[0:30]
    # to_print = [','.join(str(int(row)) for row in a)]
    # print 'The maximum votes:', to_print
    return H

def compute_gradients_thetas(img_edges, edge_points, blur_filter_size):
    img_edges = np.asfarray(img_edges)
    if blur_filter_size > 0:
        img_edges = cv2.GaussianBlur(img_edges, (blur_filter_size, blur_filter_size), 0)

    sobel_x, sobel_y = compute_gradients(img_edges)

    thetas = np.zeros(edge_points.shape[0])
    index = 0
    for i,j in edge_points:
        if sobel_x[i,j] == 0 and sobel_y[i,j] == 0:
            thetas[index] = np.inf
        elif sobel_y[i,j] == 0:
            thetas[index] =  np.pi/2 if sobel_x[i,j] > 0 else 3 * np.pi/2
        else:
            thetas[index] = np.arctan(sobel_x[i,j]/sobel_y[i,j])
        index += 1
    return thetas

#as everywhere x represent the firs axis (vertical one), y the second axis (horizontal one)
# sobel_x - the sobel on the vertical direction
# sobel_y - the soble on the horizontal direction
def compute_gradients(image):
    # kx = 0.125 * np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]])
    # ky = 0.125 * np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
    # sobel_x = cv2.filter2D(image, -1, kx)
    # sobel_y = cv2.filter2D(image, -1, ky)
    sobel_y = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=5)
    sobel_x = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=5)
    return sobel_x, sobel_y

#vote for all points which can be the center of the circle with given radius, whcih circle contains the given edge_point
# theta - the angle made by the image gradient at the edge point with the horizontal axis
def vote_for_point_plus_gradient_line(H, edge_point, theta, radius, theta_range):
    x0 = edge_point[0]
    y0 = edge_point[1]
    for theta0 in np.arange(theta - theta_range * np.pi / 180, theta + (1 + theta_range) * np.pi / 180, np.pi / 180):
        increment_vote_count(x0, y0, theta0, radius, H)
        # increment_vote_count(x0, y0, np.pi - theta0, radius, H)
        # increment_vote_count(x0, y0, np.pi / 2 - theta0, radius, H)
        # increment_vote_count(x0, y0, 3 * np.pi / 2 - theta0, radius, H)
        increment_vote_count(x0, y0, theta0 + np.pi/2, radius, H)
        increment_vote_count(x0, y0, theta0  + np.pi, radius, H)
        increment_vote_count(x0, y0, theta0 + 3*np.pi/2, radius, H)

    return H

# go in the direction of theta from (x0,y0) for a distance = radius
# if the point such obtained is inside the image H, increment the H[x,y] vote count
def increment_vote_count(x0, y0, theta0,radius, H):
    x = x0 + radius * np.sin(theta0)
    y = y0 + radius * np.cos(theta0)
    #print radius * np.sin(theta0), radius * np.cos(theta0)
    if x >= 0 and y > 0 and x < H.shape[0] and y < H.shape[1]:
        H[int(x), int(y)] += 1


def find_circles(img_orig, edge_img, radii, hough_threshold, nhood_delta, theta_range = 0, collision_detection_range = (6,6)):
    """Finds circles in the input edge image using the Hough transform and the point plus gradient
    method.

    In this method you will call both hough_circles_acc and hough_peaks.

    The goal here is to call hough_circles_acc iterating over the values in 'radii'. A Hough accumulator
    is generated for each radius value and the respective peaks are identified. It is recommended that
    the peaks from all radii are stored with their respective vote value. That way you can identify which
    are true peaks and discard false positives.

    Args:
        img_orig (numpy.array): original image. Pass this parameter to hough_circles_acc.
        edge_img (numpy.array): edge image (every nonzero value is considered an edge).
        radii (list): list of radii values to search for.
        hough_threshold (int): minimum pixel intensity value in the accumulator array to
                               search for peaks. Pass this value to hough_peaks.
        nhood_delta (tuple): a pair of integers indicating the distance in the row and
                             column indices deltas over which non-maximal suppression should
                             take place. Pass this value to hough_peaks.

    Returns:
        numpy.array: array with the circles position and radius where each row
                     contains [row_id, col_id, radius]
    """

    votes_array = []
    d = dict() # map tuple (x,y) to (radius, votesCount)
    for radius in radii:
        H = hough_circles_acc(img_orig, edge_img,radius, theta_range=theta_range)
        peaks = hough_peaks(H,hough_threshold,nhood_delta)
        for peak in peaks:
            x = peak[0]
            y = peak[1]
            votes = H[x,y]
            if not d.has_key((x,y)):
                d[(x,y)] = (radius,votes)
            if d.has_key((x,y)) and d[(x,y)][1] < votes:
                d[(x, y)] = (radius, votes)

    for key in d.keys():
        x = key[0]
        y = key[1]
        radius = d[key][0]
        votes = d[key][1]
        votes_array.append(np.array([x,y,votes]))
    votes_array = np.array(votes_array)
    #transform it an accumulator array structure, to be able to use hough_peaks for local maximum suppression
    #i.e. if there are several circles with centers near each other, keep only the circle with the highes votes
    acc_array = np.zeros(img_orig.shape)
    for vote in votes_array:
        acc_array[vote[0],vote[1]] = vote[2]
    peaks = hough_peaks(acc_array,1,collision_detection_range)
    res = []
    for peak in peaks:
        x = peak[0]
        y = peak[1]
        if (x,y) in d.keys():
            radius = d[(x,y)][0]
            votes = d[(x,y)][1]
            res.append(np.array([x,y,radius,votes]))
    res = np.array(res)
    res = sorted(res, key = lambda row: -row[3])
    return np.array(res)[:,(0,1,2)]
